<?php
// include('./layout/header.php');
include('./layout/nav.php');
include('./layout/slide.php');

?>