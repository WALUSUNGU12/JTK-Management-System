<?php
 require '../auth/check_auth.php';

include('./sidebar.php');

?>